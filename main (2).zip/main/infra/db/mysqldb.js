
function getConnection(){

    const mysql = require('mysql2/promise');

    if(global.connection && global.connection.status == "disconnected"){
        return global.connection;
    }

    global.connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password:'gnrifpe',
        database: 'emp'
      });

      return global.connection;

    }

    module.exports ={getConnection}