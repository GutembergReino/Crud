const e = require('express');
const express = require('express');
const exphbs = require('express-handlebars');

const empregadoDAO = require('./repository/EmpregadoDAO');

const PORT = 9000;


const app =express();
app.use(express.urlencoded({extended:true}));

hbs = exphbs.create({
    defaultLayout:"main",
    extname:'hbs'
});

app.engine('hbs',hbs.engine);
app.set('view engine','hbs');

app.get('/',(req,res)=>{
res.status(200).send("App Running!");
});

app.get('/empregados',async (req,res)=>{
    const [empregados] = await empregadoDAO.listarEmpregado();
    res.render('main',{layout:'empregados/listar',empregados});
});

app.get('/empregados/novo',async(req,res)=>{
    res.render('main',{layout:'empregados/form'});
});

app.post('/empregados',async(req,res)=>{
    const empregado ={
        "nome": req.body.nome,
        "endereco": req.body.endereco,
        "telefone": req.body.telefone,
        "email": req.body.email
    }

   await empregadoDAO.salvarEmpregado(empregado);
    res.redirect('/empregados');
});

app.get('/empregados/editar', async (req,res)=>{
    const [empregados] = await empregadoDAO.getEmpregadoById(req.query.id);
    console.log("EMPREGADOS::EDITAR "+JSON.stringify(empregados));
    const empregado = empregados[0];
    res.render('main', {layout:'empregados/form',empregado});
});

app.get('/empregados', async (req,res)=>{
    const [empregados] = await empregadoDAO.listarEmpregado();
    res.render('main',{layout: 'empregados/listar', empregados});
});

app.get('/empregados/remover', async(req,res)=>{
    await empregadoDAO.removerEmpregado(req.query.id);
    res.redirect('/empregados')
})

app.listen(PORT,()=>{
    console.log(`Site rodando na porta ${PORT}`);
})