const mysql = require('../infra/db/mysqldb');

async function salvarEmpregado(empregado){
    const SQL_INSERT = `insert into empregado(nome,endereco,telefone,email) values (?,?,?,?)`;
    const con = await mysql.getConnection();
    const values =[empregado.nome,empregado.endereco,empregado.telefone,empregado.email];
    return await con.execute(SQL_INSERT,values);

}

async function listarEmpregado(){
    const SQL_SELECT = 'select id,nome,endereco,telefone,email from empregado';
    const con = await mysql.getConnection();
    return await con.execute(SQL_SELECT);
}

async function atualizarEmpregado(empregado){
    const SQL_UPDATE = 'update empregado set nome=?, endereco=?, telefone, email from empregado';
    const con = await mysql.getConnection();
    const values = [id];
    return await con.execute(SQL_UPDATE,values);
}

async function removerEmpregado(id){
    const SQL_DELETE = 'delete from empregado where id=?';
    const con = await mysql.getConnection();
    const values = [id];
    return await con.execute(SQL_DELETE,values);
}

async function getEmpregadosById(id){
    console.log('ID'+id);
    const SQL_SELECT_ID = 'select id,nome,endereco,telefone,email from empregado where id=?';
    const con = await mysql.getConnection();
    const values = [id];
    return await con.execute(SQL_SELECT);
}

module.exports = {salvarEmpregado,listarEmpregado,atualizarEmpregado,removerEmpregado,getEmpregadosById}